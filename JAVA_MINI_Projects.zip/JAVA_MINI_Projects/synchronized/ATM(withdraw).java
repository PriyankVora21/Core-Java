class abc
{ 
 int amount=100000;
 synchronized void s(int rupee)throws Exception
 {
  //Thread.sleep(1000);	
  if((amount-rupee)>30000)
  { 
   amount=amount-rupee;
   System.out.println(amount);
  }
  else
  {
 	System.out.println("NOT");
  }
 }
}
class xyz implements Runnable
{
 abc a1=new abc();
 int rupee;
 Thread t=new Thread(this);
 xyz(abc a,int p)
 {
  a1=a;
  rupee=p;
  t.start();
 }
 public void run()
 {
 	try
 	{
     a1.s(rupee);		
 	}catch(Exception e){}

 }

}
class main
{
 public static void main(String z[])
 {
  abc a=new abc();
  xyz x1=new xyz(a,60000);
  xyz x2=new xyz(a,30000); 
  xyz x3=new xyz(a,4000); 
  xyz x4=new xyz(a,5000); 
  xyz x5=new xyz(a,6000); 
 }	
}