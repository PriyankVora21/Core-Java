class abc
{
 synchronized void s()throws Exception
 {
  System.out.println("HIII");
  Thread.sleep(1000);
  System.out.println("BYEEE");
 }	
}
class xyz implements Runnable
{
 abc a1=new abc();
 Thread t=new Thread(this);
 xyz(abc a)
 {
  a1=a;
  t.start();	
 }
public void run()
{
  try
  {
    a1.s();
  }catch(Exception e){}
}

}
class main
{
 public static void main(String z[])throws Exception
 {abc a=new abc();
  xyz x1=new xyz(a); 
  //Thread.sleep(2000);
  xyz x2=new xyz(a); 
      xyz x3=new xyz(a); 
        xyz x4=new xyz(a); 
 }
}