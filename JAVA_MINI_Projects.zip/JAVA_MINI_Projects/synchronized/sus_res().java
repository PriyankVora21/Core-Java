class th extends Thread
{int flag=0;
 th(String s)
 {  
 	setName(s);
 	start();
 }
 public void run()
 {
 	for(int i=0;i<10;i++)
 	{
 		System.out.println(getName()+" "+i);
 		try
 		{
 			Thread.sleep(100);
 		}catch(Exception e){}
 	//	synchronized(this)
 	//	{
 		while(flag==1)
 		{
 		  try
 		  {
 		  	wait();
          }catch(Exception e){}
 		}
 	//	}	

    }	
 }
 void sus()
 {
 	flag=1;
 }
 synchronized void res()
 {
  flag=0;
  notifyAll();
 }

}
class main
{
 public static void main(String z[])throws Exception
 {	
   th t1=new th( "AAAA");
   th t2=new th( "BBBB");
   Thread.sleep(400);
   t1.sus();
   Thread.sleep(500);
   t1.res();
   
 }
}