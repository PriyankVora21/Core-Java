import java.io.*;
class train
{
 void createfile()throws Exception
 {
 File f=new File("traindata1.txt");
  f.createNewFile();	
 }	 
 void design()throws Exception
 {
  FileWriter w=new FileWriter("traindata1.txt");
  BufferedWriter b1=new BufferedWriter(w);
  b1.write("NAME          NUMBER          PICKUPPOINT          DESTINATION");
  b1.newLine();
  b1.close();
 }
 void insert()throws Exception
 {
  FileWriter w=new FileWriter("traindata1.txt",true);
  BufferedWriter b1=new BufferedWriter(w);
  InputStreamReader i1=new InputStreamReader(System.in);
  BufferedReader b2=new BufferedReader(i1);
 
  System.out.println("ENTER TRAIN NAME :-"); 
  String s1=b2.readLine();

  b1.write(s1);
  b1.write("          ");

  System.out.println("ENTER TRAIN NO:-"); 
  String s2=b2.readLine();

  b1.write(s2);
    b1.write("          ");

  System.out.println("ENTER PICKUP POINT:-");
  String s3=b2.readLine();
  b1.write(s3);
   b1.write("          ");


  System.out.println("ENTER DESTINATION POINT:-"); 
  String s4=b2.readLine();
  b1.write(s4);
  b1.newLine();
  b1.close();
 }	
 void search()throws Exception
 {
  FileReader fr=new FileReader("traindata1.txt");
  BufferedReader br=new BufferedReader(fr);

  InputStreamReader i4=new InputStreamReader(System.in);
  BufferedReader b4=new BufferedReader(i4);
  String in;
  System.out.println("ENTER TRAIN NUMBRE OR TRAIN NAME:-");

  in= b4.readLine();
  int flag=0;
  String sr;
  while((sr=br.readLine())!=null)
  {
     String k[]= sr.split("          ");
     for(int i=0;i<=1;i++)
     {
      if((in.compareTo(k[i])==0))
      {

      	System.out.println(sr);
      	flag=1;
      }	
     }
   }
   if(flag==0)
   {
      	System.out.println("\nPlease enter appropriate choice.");
   }
 }
}
class main
{
 public static void main(String z[])throws Exception
 {
  train oi=new train();
  oi.createfile();
  //oi.design();

  int c=0;

  while(c!=-1)
  {	
   System.out.println("1.INSERT");
   System.out.println("2.EXIT");
   System.out.println("3.SEARCH");
   System.out.println("ENTER THE CHOICE:-");
   InputStreamReader i=new InputStreamReader(System.in);
   BufferedReader b=new BufferedReader(i);
    int num=b.read();
   switch((char)num)
   {
    case '1':
    oi.insert();
    break;
    case '2':
    System.exit(0);
    case '3':
     oi.search();
     break;
    default:
       System.out.println("WRONG CHOICE TRY AGAIN");
       break;
    }
  }


 }	
}