import java.io.*;
import java.util.*;
class Student
{
   void add_data(String s)throws Exception
   {  
     FileWriter fout=new FileWriter(s,true);
     BufferedWriter b=new BufferedWriter(fout);

     InputStreamReader i=new InputStreamReader(System.in);
     BufferedReader br=new BufferedReader(i);

     System.out.println("ENTER YOUR NAME:-");
     String s1=br.readLine();
     b.write(s1+"   ");
     System.out.println("ENTER YOUR ENROLLEMENT NUMBER:-");
     String s2=br.readLine();
     b.write(s2+"   ");
     System.out.println("ENTER YOUR DEPARTMENT:-");
     String s3=br.readLine();
     b.write(s3+"   ");
     b.newLine();

     b.close();
    }
    void find_by_enroll(String s)throws Exception
    {
      InputStreamReader i=new InputStreamReader(System.in);
      BufferedReader b=new BufferedReader(i);
      System.out.println("ENTER ENROLLEMENT NUMBER OF STUDENT FOR FIND DETAIL :-");
      String s2=b.readLine();

      FileReader fin=new FileReader(s);
      BufferedReader b1=new BufferedReader(fin);

      int flag=0;
      String s1;  
      String s3[]=new String[100];
      while((s1=b1.readLine())!=null)
      { 
         String s4[]=s1.split("   "); 
         if(s4[1].equals(s2))
         {
           System.out.println("Details Of Student Are :- ");
           System.out.println("NAME :- "+s4[0]);
           System.out.println("Enrollment :- "+s4[1]);
           System.out.println("Department :- "+s4[2]);
           flag=1;
         }
         if(s4[0].equalsIgnoreCase(s2)||s4[2].equalsIgnoreCase(s2))
         { System.out.println("Please Enter Enrolment instead of Name or Department"); flag=1; break; }
      }b1.close();
      if(flag==0)  System.out.println("NOT FOUND !");
    }
    void remove_data(String s)throws Exception
    {
      InputStreamReader i=new InputStreamReader(System.in);
      BufferedReader b=new BufferedReader(i);
      System.out.println("ENTER ENROLLEMENT NUMBER OF STUDENT FOR REMOVE DETAIL :-");
      String enroll=b.readLine();

      File ff=new File(s);
      FileReader fin=new FileReader(ff);
      BufferedReader br=new BufferedReader(fin);
      File ff1=new File("tmp.txt");
      FileWriter fout=new FileWriter(ff1);
      BufferedWriter bw=new BufferedWriter(fout);

      int flag=0; String s1;
      while((s1=br.readLine())!=null)
      {
         String arr[]=s1.split("   ");
         if(arr[0].equalsIgnoreCase(enroll)||arr[2].equalsIgnoreCase(enroll))
         { System.out.println("Please Enter Enrolment instead of Name or Department"); flag=1; break; }
         else
         { if(!arr[1].equals(enroll))
           {
            bw.write(s1);
            bw.newLine();
           }
         }
      }
    bw.close();  br.close();
    ff.delete();
    File ff2=new File(s);
    ff1.renameTo(ff);
  }
}  
class test
{
  public static void main(String[] args)throws Exception
  {
   Student s=new Student(); String c;
   do
   {
     System.out.println("1.ADD DATA INTO FILE");  
     System.out.println("2.FIND DATA FROM FILE"); 
     System.out.println("3.REMOVE DATA FROM FILE"); 
     System.out.println("4.EXIT");   
     System.out.println("-:-----ENTER YOUR CHOICE FROM ABOVE-------:-");  
     Scanner sc=new Scanner(System.in);
     c=sc.nextLine();
     switch(c)
     {
       case "1":
        s.add_data("STUDENT_DATA.TXT"); break;
       case "2":  
        s.find_by_enroll("STUDENT_DATA.TXT");  break;
       case "3":  
        s.remove_data("STUDENT_DATA.TXT");  break;
       case "4":  break;
       default:
        System.out.println("ENTER APPROPRIATE CHOICE !");  
     }System.out.println("------------------------------------------------------------------");  
   }while(!c.equals("4"));
  }
}
